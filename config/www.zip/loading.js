// Layar loading NYR Musik. Berjalan penuh tanpa internet: semua berkas dibaca dari aplikasi sendiri
// (APK) atau dari cache (PWA), lalu masuk ke halaman utama.
(function () {
  "use strict";
  var TUJUAN = "./nyr-msc-strm/index.html";
  var BERKAS = [
    "nyr-msc-strm/index.html", "nyr-msc-strm/style.css", "nyr-msc-strm/config.js", "nyr-msc-strm/zip.js",
    "nyr-msc-strm/data.js", "nyr-msc-strm/net.js", "nyr-msc-strm/app.js", "nyr-msc-strm/icons/icon-192.png"
  ];
  var MIN_MS = 1200;    // tampil minimal supaya tidak berkedip
  var BATAS_MS = 7000;  // paling lama menunggu pemanasan berkas

  var isi = document.getElementById("isi");
  var status = document.getElementById("status");
  var offline = document.getElementById("offline");
  var mulai = Date.now();
  var pindah = false;

  if (typeof navigator !== "undefined" && navigator.onLine === false) offline.hidden = false;

  function progres(persen, teks) {
    isi.style.width = persen + "%";
    if (teks) status.textContent = teks;
  }

  function masuk() {
    if (pindah) return;
    pindah = true;
    progres(100, "Membuka aplikasi...");
    var sisa = Math.max(0, MIN_MS - (Date.now() - mulai));
    setTimeout(function () { window.location.replace(TUJUAN); }, sisa);
  }

  // Daftarkan service worker (PWA) hanya di web biasa, bukan di dalam APK.
  try {
    var h = window.location.hostname;
    if ("serviceWorker" in navigator && window.location.protocol === "https:" && h !== "appassets.androidplatform.net") {
      navigator.serviceWorker.register("sw.js").catch(function () { /* PWA opsional */ });
    }
  } catch (e) { /* abaikan */ }

  function panaskan() {
    var selesai = 0;
    return BERKAS.reduce(function (rantai, berkas) {
      return rantai.then(function () {
        return fetch(berkas, { cache: "force-cache" }).catch(function () { /* tetap lanjut */ }).then(function () {
          selesai++;
          progres(Math.round((selesai / BERKAS.length) * 90), "Memuat aplikasi... " + selesai + "/" + BERKAS.length);
        });
      });
    }, Promise.resolve());
  }

  setTimeout(masuk, BATAS_MS);
  if (typeof fetch === "function" && window.location.protocol !== "file:") {
    panaskan().then(masuk, masuk);
  } else {
    progres(60, "Memuat aplikasi...");
    setTimeout(masuk, 400);
  }
})();
